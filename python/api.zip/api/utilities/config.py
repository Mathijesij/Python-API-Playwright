import configparser

config = configparser.ConfigParser()

config.read('C:\\Users\\MathijesiJohnbritto\\PycharmProjects\\demo\\python\\api\\utilities\\config.ini')

def get_api_base_url():
    return config["API"]["base_url"]

def get_credentials():
    return dict(config["Credentials"])

def get_new_user_payload():
    return dict(config["NewUser"])

def get_search_product():
    return dict(config['searchProduct'])

def get_valid_login():
    return dict(config['ValidLogin'])

def get_password():
    return dict(config['withoutEmail'])

def get_update_user():
    return dict(config['UpdateUser'])

def get_user_by_email():
    return dict(config['getUser'])

def get_delete_user():
    return dict(config['deleteAccount'])



