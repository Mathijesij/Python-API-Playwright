class LoginLocators:
    username_placeholder = "Username"
    password_placeholder = "Password"
    login_btn_text = "Login"
