data = {
  "username":"Admin",
  "password":"admin123",

  "emp_password": "Jordan@2403",
  "confirm_password": "Jordan@2403",

  "nationality": "Indian",
  "dob": "2002-21-06",
  
  "street_1": "538 Teal Plaza",
  "street_2": "Mysore",
  "city": "Secaucus",
  "state": "NJ",
  "zip_code": "51217",
  "country": "India",

  "dependants_dob" : "2012-21-06",

  "salary_component" : "Bonus",

  "currency" : "United States Dollar"
}
